//
//  DRMyOrderViewController.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DRMyOrderViewController.h"
#import "DRMyOrderCell.h"
@interface DRMyOrderViewController ()<UITableViewDelegate,UITableViewDataSource,CallclickDelegate>{
    
    NSArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end

@implementation DRMyOrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:_orderType leftButtonShow:YES rightButtom:nil];
    [self setUITableview];
}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"DRMyOrderCell" bundle:nil] forCellReuseIdentifier:@"DRMyOrderCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [self.tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableview.mj_header endRefreshing];
        [SVProgressHUD dismiss];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self setUpData];
        }else{
            [SVProgressHUD showErrorWithStatus:@"暂无数据!"];
        }
    });
}

- (void)setUpData{
    if([_orderType isEqualToString:@"科目一"]){
    _datasource  =@[@{@"id":@"科目一",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"已接单",
                                       @"推送标识":@(1),
                                       @"color":@"#66CDAA",
                                       @"name":@"李先生",
                                       },
                                     @{@"id":@"科目一",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"已接单",
                                       @"推送标识":@(2),
                                       @"color":@"#66CDAA",
                                       @"name":@"王先生",
                                       },
                                     @{@"id":@"科目一",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"未接单",
                                       @"推送标识":@(1),
                                       @"color":@"#FF0000",
                                       @"name":@"周小姐",
                                       },
                                     @{@"id":@"科目一",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"未接单",
                                       @"推送标识":@(3),
                                       @"color":@"#FF0000",
                                       @"name":@"元先生",
                                       },
                                     @{@"id":@"科目一",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"未接单",
                                       @"推送标识":@(1),
                                       @"color":@"#FF0000",
                                       @"name":@"刘小姐",
                                       }];
    }else if([_orderType isEqualToString:@"科目二"]){
        _datasource  =@[@{@"id":@"科目二",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"已接单",
                          @"推送标识":@(1),
                          @"color":@"#66CDAA",
                          @"name":@"李先生",
                          },
                        @{@"id":@"科目二",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"已接单",
                          @"推送标识":@(2),
                          @"color":@"#66CDAA",
                          @"name":@"王先生",
                          },
                        @{@"id":@"科目二",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"未接单",
                          @"推送标识":@(1),
                          @"color":@"#FF0000",
                          @"name":@"刘小姐",
                          }];
    }else if([_orderType isEqualToString:@"科目三"]){
        _datasource  =@[@{@"id":@"科目三",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"已接单",
                          @"推送标识":@(1),
                          @"color":@"#66CDAA",
                          @"name":@"李先生",
                          },
                        @{@"id":@"科目三",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"已接单",
                          @"推送标识":@(2),
                          @"color":@"#66CDAA",
                          @"name":@"王先生",
                          },
                        @{@"id":@"科目三",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"未接单",
                          @"推送标识":@(1),
                          @"color":@"#FF0000",
                          @"name":@"周小姐",
                          },
                        @{@"id":@"科目三",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"未接单",
                          @"推送标识":@(3),
                          @"color":@"#FF0000",
                          @"name":@"元先生",
                          },
                        ];
    }else if([_orderType isEqualToString:@"科目四"]){
        _datasource  =@[@{@"id":@"科目四",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"已接单",
                          @"推送标识":@(1),
                          @"color":@"#66CDAA",
                          @"name":@"李先生",
                          },
                        @{@"id":@"科目四",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"已接单",
                          @"推送标识":@(2),
                          @"color":@"#66CDAA",
                          @"name":@"王先生",
                          },
                        @{@"id":@"科目四",
                          @"date":@"2019-05-10 09:06:30",
                          @"抢单标识":@"未接单",
                          @"推送标识":@(1),
                          @"color":@"#FF0000",
                          @"name":@"周小姐",
                          },
                        ];
    }
    [self.tableview reloadData];
    
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100.f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"DRMyOrderCell";
    
    DRMyOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[DRMyOrderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    NSDictionary *dict=_datasource[indexPath.row];
    cell.namelb.text=isnull(dict[@"name"]);
    cell.typelb.text=isnull(dict[@"id"]);
    cell.datelb.text=isnull(dict[@"date"]);
    
    return cell;
}

- (void)callclick:(UIButton *)sender{
    
    NSMutableString *str=[[NSMutableString alloc] initWithFormat:@"telprompt://%@",@"+8615575214723"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",str]]];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
