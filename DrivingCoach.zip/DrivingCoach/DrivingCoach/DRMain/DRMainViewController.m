//
//  DRMainViewController.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DRMainViewController.h"
#import "DRMainViewCell.h"
#import "DRMainCollectionViewCell.h"
#import "DRMyOrderViewController.h"
@interface DRMainViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UIAlertViewDelegate>{
    UICollectionViewFlowLayout *flowLayout_;
    NSMutableArray *_textArr;//mid
    NSMutableArray *_imgArr; //mid
    NSArray *_imageArr;//top
    NSArray *_textDataArr;
    NSArray *_imgdata;
    NSTimer *_timer;
}
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)UIScrollView *scrollview;
@property(nonatomic,strong)UIPageControl *control;
@end

@implementation DRMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _imgArr=[NSMutableArray array];
    _textArr=[NSMutableArray array];
    [self setNaviTitle:@"首页" leftButtonShow:NO rightButtom:nil];
        [self initCollectionView];
        [self setUITableview];
    _textDataArr= @[@"科目一",@"科目二",@"科目三",@"科目四"];
    _imageArr=@[@"chaiji_icon",@"kancha_icon",@"kancha",@"kanchazi"];
    [self setUI];
    [self addtimer];
}

- (void)setUI{
    
    _imgdata=@[@"jiakaozhushou",@"jiaolian",@"jiakaobanner3"];
    [self.view addSubview:self.scrollview];
    _control=[[UIPageControl alloc]initWithFrame:CGRectMake((kScreenW-80)/2, 180, 80, 20)];
    _control.numberOfPages=_imgdata.count;
    _control.currentPageIndicatorTintColor=[UIColor colorWithHexString:@"#FF6347"];
    _control.pageIndicatorTintColor=[UIColor grayColor];
    [self.view addSubview:_control];
}
- (UIScrollView *)scrollview{
    
    if(!_scrollview){
        
        _scrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 200)];
        _scrollview.contentSize=CGSizeMake(kScreenW*_imgdata.count, 0);
        [_scrollview setPagingEnabled:YES];
        [_scrollview setDelegate:self];
        [_scrollview setBounces:NO];
        [_scrollview setUserInteractionEnabled:YES];
        [_scrollview setShowsHorizontalScrollIndicator:NO];
        [_scrollview setShowsVerticalScrollIndicator:NO];
        for(int i=0;i<_imgdata.count;i++){
            
            UIImageView *img=[[UIImageView alloc]initWithFrame:CGRectMake(i*kScreenW, 0, kScreenW, 200)];
            img.image=[UIImage imageNamed:_imgdata[i]];
            img.userInteractionEnabled=YES;
            [_scrollview addSubview:img];
        }
        
    }
    return _scrollview;
}
//初始化数据
-(void)setUpData{
    
  
    [_textArr addObjectsFromArray :@[@{@"id":@"科目一考试",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"已接单",
                                       @"推送标识":@(1),
                                       @"color":@"#66CDAA",
                                       },
                                     @{@"id":@"科目三考试",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"已接单",
                                       @"推送标识":@(2),
                                       @"color":@"#66CDAA",
                                       },
                                     @{@"id":@"科目三考试",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"未接单",
                                       @"推送标识":@(1),
                                       @"color":@"#FF0000",
                                       },
                                     @{@"id":@"科目四考试",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"未接单",
                                       @"推送标识":@(3),
                                       @"color":@"#FF0000",
                                       },
                                     @{@"id":@"科目二考试",
                                       @"date":@"2019-05-10 09:06:30",
                                       @"抢单标识":@"未接单",
                                       @"推送标识":@(1),
                                       @"color":@"#FF0000",
                                       }]];
    [ _imgArr addObjectsFromArray: @[@"Group 20 Copy 2",@"Group 20 Copy 2",@"Group 20",@"Group 20",@"Group 20"]];
    [self.tableView reloadData];
}

- (void)addtimer{
     
    
      _timer = [NSTimer timerWithTimeInterval:2.0
                                               target:self
                                             selector:@selector(repeatPage)
                                             userInfo:nil
                                              repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    
}





- (void)repeatPage

{
    
        int page = 0;
    
        if (self.control.currentPage == _imgdata.count-1) {
        
                page =0;
        
            }else{
            
                    page = (int)self.control.currentPage + 1;
            
                }
    
        
    
        // 计算滚动位置
    
        
    
        CGFloat offsetX = page * _scrollview.frame.size.width;
    
        CGPoint offset = CGPointMake(offsetX, 0);
    
        
    
        [_scrollview setContentOffset:offset animated:YES];
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView

{
    
        CGFloat scrollX = _scrollview.frame.size.width;
    
        int page = (scrollView.contentOffset.x + scrollX * 0.5 ) / scrollX;
    
        self.control.currentPage = page;
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
   
    _control.currentPage=scrollView.contentOffset.x/kScreenW;
    
    
}
- (void)setUITableview{
    
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    [self.tableView registerNib:[UINib nibWithNibName:@"DRMainViewCell" bundle:nil] forCellReuseIdentifier:@"DRMainViewCell"];
    self.tableView.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
        self.tableView.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
        [self.tableView.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableView.mj_header endRefreshing];
        [SVProgressHUD dismiss];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
//        if([namestr isEqualToString:@"15976070261"]){
            [self setUpData];
//        }else{
//            [SVProgressHUD showErrorWithStatus:@"暂无抢单数据!"];
//        }
    });
}
#pragma mark - ---------- 初始化CollectionView ----------
- (void)initCollectionView {
    flowLayout_ = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout_ setScrollDirection:UICollectionViewScrollDirectionVertical];
    self.collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.delaysContentTouches = YES;
    self.collectionView.pagingEnabled = NO;
    [self.collectionView setDataSource:self];
    [self.collectionView setDelegate:self];
    self.collectionView.backgroundColor=[UIColor whiteColor];
    [self.collectionView registerNib:[UINib nibWithNibName:@"DRMainCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"DRMainCollectionViewCell"];
    
}



//设置每个item的尺寸
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    return CGSizeMake(kScWidth/4, kScWidth/4);
    
}

//设置每个item的UIEdgeInsets
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0,0,0,0);
}

//设置每个item水平间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
}


//设置每个item垂直间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0;
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _textDataArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    DRMainCollectionViewCell *cell = (DRMainCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"DRMainCollectionViewCell" forIndexPath:indexPath];
    cell.textlb.text=_textDataArr[indexPath.row];
    cell.img.image=[UIImage imageNamed:_imageArr[indexPath.row]];
    
    return cell;
}


#pragma mark - ---------- 每个Cell的点击事件 ----------
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.row==7){
        self.tabBarController.selectedIndex=1;
    }else{
        DRMyOrderViewController *vc=[DRMyOrderViewController new];
        vc.orderType=_textDataArr[indexPath.row];
        [self pushViewController:vc];
    }
    
    
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _textArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100.f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"DRMainViewCell";
    
    DRMainViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[DRMainViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    NSDictionary *dict=_textArr[indexPath.row];
    cell.imgView.image = [UIImage imageNamed:_imgArr[indexPath.row]];
    cell.label0.text =[NSString stringWithFormat:@"学习科目:%@",dict[@"id"]];
    cell.label1.text =[NSString stringWithFormat:@"抢单时限:%@",dict[@"date"]];
    cell.bottomlb.text=[NSString stringWithFormat:@"推送标识:第%zd波推送",[dict[@"推送标识"] integerValue]];
    cell.detailLb.textColor = [UIColor colorWithHexString:dict[@"color"]];
    cell.detailLb.text = dict[@"抢单标识"];
    
    return cell;
}

#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIAlertView *alterview=[[UIAlertView alloc]initWithTitle:@"提示" message:@"是否确定抢单" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
    alterview.delegate=self;
    alterview.tag=10+indexPath.row;
    [alterview show];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
    if(!autLogin || ![autLogin isEqual:@(1)]){
        LoginViewController *login=[LoginViewController new];
        [self presentViewController:login animated:YES completion:nil];
        return ;
    }
    NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:_textArr[alertView.tag-10]];
    if(buttonIndex==0){
        if(![dict[@"抢单标识"] isEqualToString:@"已接单"]){
            [dict setObject:@"已接单" forKey:@"抢单标识"];
            [dict setObject:@"#66CDAA" forKey:@"color"];
            [_textArr replaceObjectAtIndex:alertView.tag-10 withObject:dict];
            [_imgArr replaceObjectAtIndex:alertView.tag-10 withObject:@"Group 20 Copy 2"];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
            //            [SVProgressHUD showSuccessWithStatus:@"抢单成功!"];
            [[[UIToastView alloc]initWithTitle:@"抢单成功!"]show];
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                [[[UIToastView alloc]initWithTitle:@"该工单已被抢!"]show];
            });
            
        }
        
    }
}
- (void)click:(UIButton *)sender{
    
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
