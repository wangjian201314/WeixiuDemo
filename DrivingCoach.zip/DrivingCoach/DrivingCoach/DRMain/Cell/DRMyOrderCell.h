//
//  DRMyOrderCell.h
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol CallclickDelegate <NSObject>

- (void)callclick:(UIButton *)sender;
@end

@interface DRMyOrderCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UILabel *typelb;
@property (weak, nonatomic) IBOutlet UILabel *datelb;
@property (nonatomic, assign)id<CallclickDelegate>delegate;
@end

NS_ASSUME_NONNULL_END
