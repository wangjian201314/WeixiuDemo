//
//  JXTempMainViewCell.m
//  JXWWNOP
//
//  Created by kingste on 2017/7/13.
//  Copyright © 2017年 cn.mastercom. All rights reserved.
//

#import "DRMainViewCell.H"

@implementation DRMainViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    //grayline
    UIView * grayLine = [[UIView alloc]init];
    grayLine.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self addSubview:grayLine];
    grayLine.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-60-[grayLine]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"V:[grayLine(0.5)]-0-|"] options:0 metrics:nil views:NSDictionaryOfVariableBindings(grayLine)]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
