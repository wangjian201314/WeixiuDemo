//
//  DRMyOrderCell.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DRMyOrderCell.h"

@implementation DRMyOrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)callbtn:(UIButton *)sender {
    
    if(self.delegate && [self.delegate respondsToSelector:@selector(callclick:)]){
        [self.delegate callclick:sender];
    }
}

@end
