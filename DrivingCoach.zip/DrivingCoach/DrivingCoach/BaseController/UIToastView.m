//
//  UIToastView.m
//  MTNOS_SH
//
//  Created by c0ming on 13-6-5.
//  Copyright (c) 2013年 c0ming. All rights reserved.
//

#import "UIToastView.h"

#import <QuartzCore/QuartzCore.h>

#define VERTICAL_SPACE 8.f
#define HORIZONTAL_SPACE 8.f
#define BOTTOM_SPACE 80.f
#define BOTTOM_HORIZONTAL_MAX_SPACE 20.f

#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define STATUSBAR_HEIGHT [[UIApplication sharedApplication] statusBarFrame].size.height

@interface UIToastView ()

@property (nonatomic, strong)UILabel * label;

@end

@implementation UIToastView

static NSMutableArray* toastArray = nil;

#pragma mark - LifeCycle
- (id)initWithTitle:(NSString *)title {
    if (!toastArray) {
        toastArray = [NSMutableArray new];
    }
    if (self = [super init]) {
        
        self.backgroundColor = [UIColor darkGrayColor];
        self.alpha = 1.0;
        self.layer.cornerRadius = 3;
        self.layer.masksToBounds = YES;
        
        if (!_label) {
            [self setupLabel];
        }
        _label.text = title?title:@"";
        
    }
    return self;
}

- (void)setupLabel {
    _label = [[UILabel alloc]init];
    _label.textColor = [UIColor whiteColor];
    _label.lineBreakMode = NSLineBreakByWordWrapping;
    _label.textAlignment = NSTextAlignmentLeft;
    _label.numberOfLines = 0;
    _label.font = [UIFont systemFontOfSize:15.f];
    [self addSubview:_label];
}

#pragma mark - Action
- (void)show{
    
    [self layoutToastView];
    
    //显示之前先把之前的移除
    if ([toastArray count] != 0) {
        [self performSelectorOnMainThread:@selector(dismiss) withObject:nil waitUntilDone:YES];
    }
    
    @synchronized (toastArray) {
        
        UIWindow *windowView = [UIApplication sharedApplication].keyWindow;
        [windowView addSubview:self];
        
        [UIView animateWithDuration:0.5f
                              delay:0.f
             usingSpringWithDamping:0.7f
              initialSpringVelocity:0.5f
                            options:UIViewAnimationOptionCurveEaseIn
                         animations:^{
                             
                         } completion:^(BOOL finished) {
                             
                         }];
        
        [toastArray addObject:self];
        [self performSelector:@selector(dismiss) withObject:nil afterDelay:3];
        
    }
}

-(void)dismiss{
    
    if (toastArray && [toastArray count] > 0) {
        @synchronized (toastArray) {
            
            UIToastView * toast = toastArray[0];
            [NSRunLoop cancelPreviousPerformRequestsWithTarget:toast];
            [toastArray removeObject:toast];
            
            [UIView animateWithDuration:0.5f
                             animations:^{
                                 toast.alpha = 0.f;
                             } completion:^(BOOL finished) {
                                 [toast removeFromSuperview];
                             }];
        }
    }
}

-(void)layoutToastView {
    
    CGSize labelSize = [self sizeForString:_label.text font:_label.font maxWidth:[self textMaxWidth]];
    
    _label.frame = CGRectMake(HORIZONTAL_SPACE, VERTICAL_SPACE, labelSize.width, labelSize.height);
    
    CGFloat toastViewX = 0;
    CGFloat toastViewY = 0;
    CGFloat toastViewW = 0;
    CGFloat toastViewH = 0;
    
    toastViewH = labelSize.height + 2 * VERTICAL_SPACE;
    toastViewW = labelSize.width + 2 * HORIZONTAL_SPACE;
    toastViewX = (SCREEN_WIDTH - toastViewW)/2;
    toastViewY = SCREEN_HEIGHT - toastViewH - BOTTOM_SPACE;
    
    self.frame = CGRectMake(toastViewX, toastViewY, toastViewW, toastViewH);
}

#pragma mark - Other
- (CGFloat)textMaxWidth {
    CGFloat textMaxWidth = 0;
    textMaxWidth = SCREEN_WIDTH - 2*HORIZONTAL_SPACE;
    textMaxWidth -= 2*BOTTOM_HORIZONTAL_MAX_SPACE;
    return textMaxWidth;
}

- (CGSize)sizeForString:(NSString*)content font:(UIFont*)font maxWidth:(CGFloat) maxWidth{
    if (!content || content.length == 0) {
        return CGSizeMake(0, 0);
    }
    
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    paragraphStyle.alignment = NSTextAlignmentLeft;
    
    
    CGSize contentSize = [content boundingRectWithSize:CGSizeMake(maxWidth, CGFLOAT_MAX)
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                            attributes:@{NSParagraphStyleAttributeName : paragraphStyle,
                                                         NSFontAttributeName : font}
                                               context:nil].size;
    
    return contentSize;
}


- (void)dealloc {
    
#if DEBUG
    NSLog(@"%s", __func__);
#endif
    
}

@end
