//
//  Gloab.h
//  Broadband
//
//  Created by Mac on 2019/5/17.
//  Copyright © 2019年 Mac. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Gloab : NSObject
CGFloat heightForString(NSString *value, CGFloat fontSize, CGFloat width);
@end

NS_ASSUME_NONNULL_END
