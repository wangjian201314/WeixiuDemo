//
//  MTBaseViewController.h
//  First
//
//  Created by 王健 on 2019/3/23.
//  Copyright © 2019年 王健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTBaseViewController : UIViewController<UIGestureRecognizerDelegate>{
    
    
    NSArray* _leftBarItems;
    UIView *navView,*emptyView;
    
}

- (void)setNaviTitle:(NSString*)title leftButtonShow:(BOOL)leftButtonShow rightButtom:(id)rightButtom;
- (void)backAction;
- (void)pushViewController:(UIViewController *)vc;
- (void)saveLocalData:(NSMutableDictionary *) dict;//保存
- (NSDictionary *)getLocalData ;//取值
@property(nonatomic,copy)NSString *navititle;


//UIButton
-(UIButton*)buttonPhotoAlignment:(NSString*)photo hilPhoto:(NSString*)Hphoto rect:(CGRect)rect  title:(NSString*)title  select:(SEL)sel Tag:(NSInteger)tag View:(UIView*)ViewA textColor:(UIColor*)textcolor Size:(UIFont*)size background:(UIColor *)background;
+(UITextField*)addTextFieldView:(CGRect)rect Tag:(NSInteger)tag  textColor:(UIColor*)color Alignment:(NSTextAlignment)alignment Text:(NSString*)textStr  placeholderStr:(NSString *)placeholderStr View:(UIView*)viewA font:(UIFont*)font;




#pragma mark -几个参数block
@property (nonatomic,copy)  void(^completeBlockNone)(void);
@property (nonatomic,copy)  void(^completeBlockNSString)(NSString *completeStr);
@property (nonatomic,copy)  void(^completeBlockNSArray)(NSArray *completeAry);
@property (nonatomic,copy)  void(^completeBlockNSDictionary)(NSDictionary *completedic);
@property (nonatomic,copy)  void(^completeBlockMutableArray)(NSMutableArray *completeAry);
@end
