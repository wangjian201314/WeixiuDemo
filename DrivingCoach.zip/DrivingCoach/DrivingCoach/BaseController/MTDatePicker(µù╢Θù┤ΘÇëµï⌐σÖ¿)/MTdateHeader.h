//
//  MTdateHeader.h
//  UICommon
//
//  Created by Zone on 2018/4/11.
//  Copyright © 2018年 YN. All rights reserved.
//

/*
 修订: xzz X了个J 增加 注释 & 初始化方法
*/

#import <Foundation/Foundation.h>

@interface MTdateHeader : NSObject
/*
 复选时间如果想用 block 初始化你要去实例化 MTDateMultipleView
 开始时间 beginDate
 结束时间 endDate
 */
typedef void(^DateHandlerBeginEnd)(NSDate * beginDate,NSDate * endDate);

/*
 单选时间如果想用 block 初始化你要去实例化 MTDateSingleView
 单选时间 date
 */
typedef void(^DateHandler)(NSDate * date);

typedef enum{
    DateStyleYearMonthDayHourMinute = 0, /*年月日 时分*/
    DateStyleYearMonthDayHour, /*年月日时*/
    DateStyleYearMonthDayHourTenMinute, /*年月日 时分 (分是按照 00 10 20 30 40 50 60 这样选择的 10个为一个单位)*/
    DateStyleYearMonthDay,/*年月日*/
    DateStyleYearMonth, /*年月*/
    DateStyleYear, /*年*/
    DateStyleMonthDay,/*月日*/
    DateStyleHourMinute/*时分*/
}MTDateStyle;

@end
