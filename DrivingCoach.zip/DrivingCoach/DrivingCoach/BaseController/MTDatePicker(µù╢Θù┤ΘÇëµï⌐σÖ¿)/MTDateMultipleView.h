//
//  MTDateMultipleView.h
//  ZSWXWLKH
//
//  Created by kingste on 2017/6/14.
//  Copyright © 2017年 MasterCom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSDate+Extension.h"
#import "MTdateHeader.h"

@class MTDateMultipleView;
@protocol MTDateMultipleViewDelegate <NSObject>
/*
 选择 代理方式初始化时 实现下面方法接收回调
 */
- (void)MTDateMultipleView:(MTDateMultipleView *)dateMultipleView didSelectedStartDate:(NSDate *)startDate endDate:(NSDate *)endDate;

@end

@interface MTDateMultipleView : UIView

//============ 方式一 ============
- (instancetype)initWithDateStyle:(MTDateStyle)datePickerStyle DateHandler:(DateHandlerBeginEnd)dateHandler;
@property (nonatomic, strong) DateHandlerBeginEnd dateHandler;

//============ 方式二 ============
- (instancetype)initWithDateStyle:(MTDateStyle)datePickerStyle delegate:(id)delegate;
@property (nonatomic, assign)id<MTDateMultipleViewDelegate>delegate;

@property (nonatomic, retain) NSDate *maxLimitDate;//限制最大时间 默认9999
@property (nonatomic, retain) NSDate *minLimitDate;//限制最小时间 默认0

- (void)show;
- (void)dismiss;

@end
