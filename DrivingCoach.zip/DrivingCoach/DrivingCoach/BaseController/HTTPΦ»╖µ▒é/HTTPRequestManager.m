//
//  HTTPRequestManager.m
//  ChaoLiuNvZhuang1521
//
//  Created by iJeff on 15/11/20.
//  Copyright (c) 2015年 iJeff. All rights reserved.
//

#import "HTTPRequestManager.h"
/**
 *  第三方库头文件
 */
#import <AFNetworking.h>
@implementation HTTPRequestManager


//GET
+ (void)GET:(NSString *)url parameters:(id)parameters result:(ResultBlock)result
{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    manager.requestSerializer.timeoutInterval = 5;
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html",nil];
    
    [manager GET:url parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (result) {
            result(responseObject, nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (result) {
            result(nil, error);
        }
    }];
    
    
}

+ (void)Post:(NSString *)url parameters:(id)parameters result:(ResultBlock)result{
    
    // 创建管理者对象
    AFHTTPSessionManager *sessionManager = [AFHTTPSessionManager manager];
    
    sessionManager.requestSerializer = [AFJSONRequestSerializer serializer];
    sessionManager.requestSerializer.timeoutInterval = 5;
    
    [sessionManager POST:url parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
       
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (result) {
            result(responseObject, nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (result) {
            result(nil, error);
        }
    }];
}





@end







