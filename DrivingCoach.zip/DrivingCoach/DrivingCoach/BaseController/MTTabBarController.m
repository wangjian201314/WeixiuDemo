//
//  MTTabBarController.m
//  First
//
//  Created by 王健 on 2019/3/23.
//  Copyright © 2019年 王健. All rights reserved.
//

#import "MTTabBarController.h"
#import "MTNavigationController.h"

#import "DRMyViewController.h"
#import "DROrderViewController.h"
#import "DRMainViewController.h"
@interface MTTabBarController ()<UITabBarDelegate,UITabBarControllerDelegate>

@end

@implementation MTTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setTabar];
    
   
}

- (void)setTabar{
    //改变tabbarController 文字选中颜色，字体大小(默认渲染为蓝色)
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName:[UIColor lightGrayColor],NSFontAttributeName:[UIFont systemFontOfSize:14]} forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName:[UIColor colorWithHexString:@"#436EEE"],NSFontAttributeName:[UIFont systemFontOfSize:14]} forState:UIControlStateSelected];
//    [self setupOneChildViewController:[[MainViewController alloc] init] title:@"首页" image:@"应用" selectedImage:@"应用选中"];
     self.delegate=self;
    [self setupOneChildViewController:[[DRMainViewController alloc] init] title:@"首页" image:@"huHomeNal" selectedImage:@"huHomeSel"];
    [self setupOneChildViewController:[[DROrderViewController alloc] init] title:@"学员考试" image:@"qiangdanNal" selectedImage:@"qiangdanSel"];
    [self setupOneChildViewController:[[DRMyViewController alloc] init] title:@"我的" image:@"wodenal" selectedImage:@"wodeSel"];
   
    [[UITabBar appearance] setTranslucent:NO];//设置透明，iOS12否则pop时候会有tabbar错位问题
}
- (void)setupOneChildViewController:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    MTNavigationController *nav = [[MTNavigationController alloc]initWithRootViewController:vc];
    nav.view.backgroundColor = [UIColor whiteColor];  // 设置背景为随机色
    nav.tabBarItem.title = title;
    if (image.length) { // 图片名有具体值，判断图片传入值是空还是nil
        nav.tabBarItem.image = [[UIImage imageNamed:image]imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        nav.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        //[nav.tabBarItem setImageInsets:UIEdgeInsetsMake(0, 0, 5, 2)]; //
        //nav.tabBarItem.titlePositionAdjustment=UIOffsetMake(10, 10);
    }
    
    [self addChildViewController:nav];
}

//这个是UITabBarController的代理方法
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    
    // 判断哪个界面要需要再次点击刷新，这里以第一个VC为例
    if ([viewController.tabBarItem.title isEqualToString:@"我的"]) {
        // 判断再次选中的是否为当前的控制器
        NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
        if(!autLogin || ![autLogin isEqual:@(1)]){
            LoginViewController *login=[LoginViewController new];
            [self presentViewController:login animated:YES completion:nil];
            return NO;
        }else{
            return YES;
        }
        
    }
    
    return YES;
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
