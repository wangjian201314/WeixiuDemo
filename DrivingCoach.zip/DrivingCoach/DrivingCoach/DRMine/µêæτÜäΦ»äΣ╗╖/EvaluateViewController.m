//
//  EvaluateViewController.m
//  CommunityOrder
//
//  Created by Mac on 2019/6/17.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "EvaluateViewController.h"
#import "EvaluateCell.h"
#import "DRDetailViewController.h"
@interface EvaluateViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSMutableArray *_datasource;
    NSArray *_titlearr;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end

@implementation EvaluateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"我的评价" leftButtonShow:YES rightButtom:nil];
    _datasource=[NSMutableArray array];
     [self setUI];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
             [self setdata];
        }else{
            [SVProgressHUD showErrorWithStatus:@"暂无评价数据!"];
        }
    });
   
}

- (void)setUI{
    
    _tableview.delegate=self;
    _tableview.dataSource=self;
    _tableview.rowHeight=UITableViewAutomaticDimension;
        _tableview.estimatedRowHeight=200;
    _tableview.showsVerticalScrollIndicator=NO;
    _tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [_tableview registerNib:[UINib nibWithNibName:@"EvaluateCell" bundle:nil] forCellReuseIdentifier:@"EvaluateCell"];
    
   
}

- (void)setdata{
    [_datasource addObjectsFromArray:@[@{@"title":@"科目考试全都是一把过",
                                         @"time":@"2019-05-13 14:25",
                                         @"star":@"四星",
                                         @"content":@"教练人非常的nice，很有经验，多年的老司机"
                                         
                                         },
                                       @{@"title":@"考试总算是有惊无险的拿到驾照了",
                                         @"time":@"2019-05-15 17:30",
                                         @"star":@"一星",
                                         @"content":@"备注：教练很有耐心，尤其是教女生"
                                         
                                         },
                                       @{@"title":@"科目三挂了一次，害我补缴600元，难受",
                                         @"time":@"2019-06-15 16:25",
                                         @"star":@"五星",
                                         @"content":@"备注：练车不太爽，人太多了，总是预约不上考试"
                                         
                                         },
                                       @{@"title":@"科目二感觉是最难的，其他还好，就是记住别犯错就行",
                                         @"time":@"2019-06-10 14:00",
                                         @"star":@"四星",
                                         @"content":@"备注：教练不错p哦，以后谁要学车可以找他！"
                                         
                                         },
                                       @{@"title":@"对于我这个多年的驾驶年龄来讲都不算事",
                                         @"time":@"2019-05-19 19:45",
                                         @"star":@"四星",
                                         @"content":@"备注：我还用得着他叫我吗？自学成才，哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或"
                                         
                                         }]];
    _titlearr = @[@{@"id":@"科目二",
                                          @"date":@"2019-06-16 12:20:30",
                                          @"status":@"失败",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"80分",
                                          @"name":@"五先生",
                                          @"tel":@"187****6034",
                                          @"adress":@"c区2栋103",
                                          @"question":@"又没了兄弟，考驾照简直要命啊",
                                          @"num":@"第三次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"77"]),
                                          },
                                        @{@"id":@"科目二",
                                          @"date":@"2019-06-17 12:30:00",
                                          @"status":@"失败",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"70分",
                                          @"name":@"李先生",
                                          @"tel":@"189****0288",
                                          @"adress":@"d区1栋403",
                                          @"question":@"有点难啊，不知道别人怎么考的额",
                                          @"num":@"第二次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"88"]),
                                          },
                                        @{@"id":@"科目三",
                                          @"date":@"2019-07-02 17:30:00",
                                          @"status":@"失败",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"80分",
                                          @"name":@"吴小姐",
                                          @"tel":@"185****8035",
                                          @"adress":@"r区3栋203",
                                          @"question":@"没事没事，下次再努力学习吧",
                                          @"num":@"第三次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"99"]),
                                          },
                                        @{@"id":@"科目四",
                                          @"date":@"2019-07-01 16:00:00",
                                          @"status":@"失败",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"88分",
                                          @"name":@"赵先生",
                                          @"tel":@"189****6005",
                                          @"adress":@"b区4栋202",
                                          @"question":@"就差那么一点点啊，算了明天再来一趟",
                                          @"num":@"第三次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"33"]),
                                          },
                                        @{@"id":@"科目二",
                                          @"date":@"2019-06-30 17:30:00",
                                          @"status":@"失败",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"80分",
                                          @"name":@"周小姐",
                                          @"tel":@"188****8005",
                                          @"adress":@"g区3栋203",
                                          @"question":@"吸取上次的教训，这次稳了",
                                          @"num":@"第三次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"44"]),
                                          },
                                        @{@"id":@"科目一",
                                          @"date":@"2019-06-27 09:30:00",
                                          @"status":@"失败",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"86分",
                                          @"name":@"刘小姐",
                                          @"tel":@"181****8225",
                                          
                                          @"adress":@"h区3栋503",
                                          @"question":@"年纪大了，有点记忆力衰退",
                                          @"num":@"第三次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"100"]),
                                          },
                  ];
   
    [_tableview reloadData];
}
#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    EvaluateCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EvaluateCell"];
    
    if(cell == nil) {
        cell = [[EvaluateCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"EvaluateCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    [cell refreshUI:_datasource[indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DRDetailViewController *vc=[[DRDetailViewController alloc]init];
    NSDictionary *dict=_titlearr[indexPath.row];
    vc.dict=dict;
    [self pushViewController:vc];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
