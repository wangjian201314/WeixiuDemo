//
//  EvaluateCell.m
//  CommunityOrder
//
//  Created by Mac on 2019/6/17.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "EvaluateCell.h"

@implementation EvaluateCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)refreshUI:(NSDictionary *)dict{
    
    _titlestr.text=dict[@"title"];
    _datelb.text=dict[@"time"];
    _remarklb.text=dict[@"content"];
    _numlb.text=dict[@"star"];
}
@end
