//
//  EvaluateCell.h
//  CommunityOrder
//
//  Created by Mac on 2019/6/17.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EvaluateCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titlestr;
@property (weak, nonatomic) IBOutlet UILabel *datelb;
@property (weak, nonatomic) IBOutlet UILabel *remarklb;
@property (weak, nonatomic) IBOutlet UILabel *numlb;

- (void)refreshUI:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
