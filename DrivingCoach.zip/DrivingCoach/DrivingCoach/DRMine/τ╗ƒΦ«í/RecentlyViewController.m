//
//  RecentlyViewController.m
//  Maintenance
//
//  Created by Mac on 2019/6/18.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "RecentlyViewController.h"
#import "RecentlyTableViewCell.h"
@interface RecentlyViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_data;
    NSArray *_data1;
    NSArray *_data2;
    NSArray *_data3;
    NSMutableArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UIView *topview;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UILabel *numlb;

@end

@implementation RecentlyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"统计" leftButtonShow:YES rightButtom:nil];
    _datasource=[NSMutableArray array];
    CAShapeLayer *layer = [CAShapeLayer new];
    //圆环的宽度
    layer.lineWidth = 1;
    //圆环的颜色
    layer.strokeColor = [UIColor colorWithHexString:@"#F6D147"].CGColor;
    //背景填充色
    layer.fillColor = [UIColor clearColor].CGColor;
    //设置半径
    CGFloat radius = self.topview.frame.size.height/2-20;
    //按照顺时针方向
    BOOL clockWise = true;
    //初始化一个路径
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.topview.frame.size.width/2, self.topview.frame.size.height/2) radius:radius startAngle:(0) endAngle:2*M_PI clockwise:clockWise];
    layer.path = [path CGPath];
    [self.topview.layer addSublayer:layer];
    [SVProgressHUD showWithStatus:@"正在加载..."];
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
        
        
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self setdata];
            self.numlb.text=@"350单";
        }else{
            [SVProgressHUD showErrorWithStatus:@"暂无统计数据!"];
        }
    });
    [self.segment addTarget:self action:@selector(click:) forControlEvents:UIControlEventValueChanged];
}

- (void)setdata{
    
    _data=@[@"科目一",@"科目二",@"科目三",@"科目四"];
    _data1=@[@"0",@"1",@"0",@"0"];
    _data2=@[@"130",@"1",@"2",@"33"];
    _data3=@[@"230",@"3",@"20",@"0"];
    [_datasource addObjectsFromArray:_data1];
    [self setUITableview];
}
- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"RecentlyTableViewCell" bundle:nil] forCellReuseIdentifier:@"RecentlyTableViewCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
        self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
        [self.tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableview.mj_header endRefreshing];
    });
}
#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 44.f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"RecentlyTableViewCell";
    
    RecentlyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[RecentlyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.titlelb.text=_data[indexPath.row];
    cell.detaillb.text=_datasource[indexPath.row];
   
    
    
    return cell;
}

- (void)click:(UISegmentedControl *)segment{
    
    if(segment.selectedSegmentIndex==0){
        [_datasource removeAllObjects];
        [_datasource addObjectsFromArray:_data1];
        [_tableview reloadData];
    }else  if(segment.selectedSegmentIndex==1){
        [_datasource removeAllObjects];
        [_datasource addObjectsFromArray:_data2];
        [_tableview reloadData];
    }else{
        [_datasource removeAllObjects];
        [_datasource addObjectsFromArray:_data3];
        [_tableview reloadData];
    }
     [self.tableview.mj_header beginRefreshing];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
