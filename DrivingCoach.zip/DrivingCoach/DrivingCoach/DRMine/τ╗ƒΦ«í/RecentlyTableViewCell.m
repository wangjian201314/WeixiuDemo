//
//  RecentlyTableViewCell.m
//  Maintenance
//
//  Created by Mac on 2019/6/18.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "RecentlyTableViewCell.h"

@implementation RecentlyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
