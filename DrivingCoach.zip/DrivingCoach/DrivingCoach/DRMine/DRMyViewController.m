//
//  DRMyViewController.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DRMyViewController.h"
#import "UIImage+Exction.h"
#import "MyTableViewCell.h"
#import "FacebackViewController.h"
#import "ModifyPWDViewController.h"
#import "LoginViewController.h"
#import "AppDelegate.h"
#import "EvaluateViewController.h"
#import "RecentlyViewController.h"
@interface DRMyViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_imgdata;
   NSArray *_datasource;
}
@property (weak, nonatomic) IBOutlet UIImageView *headimg;
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UILabel *leftnumlb;
@property (weak, nonatomic) IBOutlet UILabel *rightlb;
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end

@implementation DRMyViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    id companystr=[[NSUserDefaults standardUserDefaults]objectForKey:@"company"];
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
        NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
        if(!autLogin || ![autLogin isEqual:@(1)]){
            self.leftnumlb.text=@"--";
            self.rightlb.text=@"--";
            self.namelb.text=companystr;
        }else{
            self.leftnumlb.text=@"100人";
            self.rightlb.text=@"99%";
            self.namelb.text=@"星星驾校";
        }
    }else{
        self.leftnumlb.text=@"--";
        self.rightlb.text=@"--";
        self.namelb.text=companystr;
        
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setNaviTitle:@"我的" leftButtonShow:NO rightButtom:nil];
    _imgdata=@[@"me_pwd",@"me_setup",@"me_update",@"me_about"];
    _datasource=@[@"修改密码",@"我的评价",@"意见反馈",@"退出"];
    _tableview.delegate=self;
    _tableview.dataSource=self;
    //    _tableview.estimatedRowHeight=200;
    _tableview.showsVerticalScrollIndicator=NO;
    _tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    [self.view addSubview:_tableview];
    [_tableview registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"MyTableViewCell"];
    id companystr=[[NSUserDefaults standardUserDefaults]objectForKey:@"company"];
    id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
    if([namestr isEqualToString:@"15976070261"]){
        self.leftnumlb.text=@"100人";
         self.rightlb.text=@"99%";
        self.namelb.text=@"星星驾校";
    }else{
        
        self.leftnumlb.text=@"--";
        self.rightlb.text=@"--";
        self.namelb.text=companystr;
        
    }
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(recognize)];
    NSString *path=[[ NSSearchPathForDirectoriesInDomains ( NSDocumentDirectory , NSUserDomainMask , YES ) firstObject ]stringByAppendingPathComponent:@"headimg"];
    NSData *imgdata=[NSData dataWithContentsOfFile:path];
    if(imgdata){
        self.headimg.image=[UIImage imageWithData:[NSData dataWithContentsOfFile:path]];
        self.headimg.image= [self.headimg.image circleImage];
    }
    
    [self.headimg addGestureRecognizer:tap];
}

#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyTableViewCell"];
    
    if(cell == nil) {
        cell = [[MyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MyTableViewCell"];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    cell.imgview.image=[UIImage imageNamed:_imgdata[indexPath.row]];
    cell.textlb.text=_datasource[indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50;
}
#pragma mark - UITableView Delegate methods

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.row) {
        case 0:{
            
            
            ModifyPWDViewController *vc=[ModifyPWDViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 1:{
            
                        EvaluateViewController *vc=[EvaluateViewController new];
                        [self pushViewController:vc];
        }
            
            break;
    
        case 2:{
            FacebackViewController *vc=[FacebackViewController new];
            [self pushViewController:vc];
        }
            
            break;
        case 3:{
            
            NSNumber * autLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"autologin"];
            if(!autLogin || ![autLogin isEqual:@(1)]){
                [SVProgressHUD showErrorWithStatus:@"请先登录！"];
            }else{
                [SVProgressHUD showWithStatus:@"退出登录..."];
                 dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [SVProgressHUD dismiss];
                    LoginViewController *login=[LoginViewController new];
                    [self.navigationController presentViewController:login animated:YES completion:nil];
                    [[NSUserDefaults standardUserDefaults]setObject:@(0) forKey:@"autologin"];
                    [[NSUserDefaults standardUserDefaults]setObject:@"" forKey:@"username"];
                    
                    
                });
            }
        }
            
            break;
            
        default:
            break;
    }
    
}

#pragma mark--更换头像
- (void)recognize{
    
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册选择", nil];
    sheet.delegate=self;
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerControllerSourceType sourcetape=UIImagePickerControllerSourceTypeCamera;
    //    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
    
    switch (buttonIndex) {
        case 0:
            sourcetape=UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            sourcetape=UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 2:
            
            return;
            break;
        default:
            break;
    }
    
    //    }
    UIImagePickerController  *imagepicker=[[UIImagePickerController alloc]init];
    imagepicker.delegate=self;
    imagepicker.allowsEditing=YES;
    imagepicker.sourceType=sourcetape;
    [self presentViewController:imagepicker animated:NO completion:nil];
    
}
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:nil];
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    self.headimg.image=[image circleImage];
    [self saveImage:image withname:@"headimg"];
}

- (void)saveImage:(UIImage *)img withname:(NSString *)name{
    
    NSData *imgdata=UIImageJPEGRepresentation(img, 0.5);
    NSString *path=[[ NSSearchPathForDirectoriesInDomains ( NSDocumentDirectory , NSUserDomainMask , YES ) firstObject ]stringByAppendingPathComponent:name];
    BOOL ishave= [imgdata writeToFile:path atomically:NO];
    if(ishave){
        
    }
    
}



- (IBAction)leftbtn:(UIButton *)sender {
    
    self.tabBarController.selectedIndex=1;
}
- (IBAction)rightbtn:(UIButton *)sender {
    
    RecentlyViewController *vc=[RecentlyViewController new];
    [self pushViewController:vc];
}

@end
