//
//  FacebackViewController.h
//  Compass
//
//  Created by Mac on 2019/5/7.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTBaseViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface FacebackViewController : MTBaseViewController

@end

NS_ASSUME_NONNULL_END
