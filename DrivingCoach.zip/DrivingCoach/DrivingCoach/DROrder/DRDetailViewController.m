//
//  DRDetailViewController.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/2.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DRDetailViewController.h"
#import "DRDetailtitleCell.h"
#import "DRDetailImgCell.h"
#import "DRDetailCommentCell.h"
#import "PLCompletedViewController.h"
@interface DRDetailViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSArray *_datasource;
    NSArray *_keydatas;
    NSInteger _types;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong)UIButton *bottombtn2;
@end

@implementation DRDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"考试详情" leftButtonShow:YES rightButtom:nil];
    _datasource=@[@"考试人:",@"考试类型:",@"时间:",@"状态:",@"考试分数:",@"电话:",@"地址:",@"补考:",@"评价:"];
    _keydatas=@[@"name",@"id",@"date",@"status",@"test",@"tel",@"adress",@"num",@"question"];
    [self setUITableview];
    
}

- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"DRDetailtitleCell" bundle:nil] forCellReuseIdentifier:@"DRDetailtitleCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"DRDetailImgCell" bundle:nil] forCellReuseIdentifier:@"DRDetailImgCell"];
    [self.tableview registerNib:[UINib nibWithNibName:@"DRDetailCommentCell" bundle:nil] forCellReuseIdentifier:@"DRDetailCommentCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [_tableview.mj_header beginRefreshing];
}

- (UIButton *)bottombtn2{
    
    if(!_bottombtn2){
        
        _bottombtn2 = [[UIButton alloc]initWithFrame:CGRectMake(20, kScreenH-kTabarHeight-55, kScreenW-40, 40)];
        _bottombtn2.backgroundColor=[UIColor orangeColor];
        [_bottombtn2 setTitle:@"立即评价" forState:UIControlStateNormal];
        [_bottombtn2 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _bottombtn2.layer.masksToBounds=YES;
        [_bottombtn2 addTarget:self action:@selector(bottomclick) forControlEvents:UIControlEventTouchUpInside];
        _bottombtn2.layer.cornerRadius=10;
        
    }
    return _bottombtn2;
}
- (void)headerRefresh{
    
    
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableview.mj_header endRefreshing];
        [self.view addSubview:self.bottombtn2];
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self.tableview reloadData];
        }else{
            
            [SVProgressHUD showErrorWithStatus:@"暂无学员考试数据!"];
            
            
        }
    });
}

- (void)bottomclick{
    
    PLCompletedViewController *vc=[PLCompletedViewController new];
    [self pushViewController:vc];
}


#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(indexPath.row==_datasource.count-1 ){
        return 200;
    }else{
        return 44;
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   if(indexPath.row==_datasource.count-1){
        static NSString *cellIdentifier = @"DRDetailImgCell";
        
        DRDetailImgCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[DRDetailImgCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.img.image=[UIImage imageWithData:_dict[@"img"]];
        
        return cell;
    }
    else{
        static NSString *cellIdentifier = @"DRDetailtitleCell";
        
        DRDetailtitleCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil) {
            cell = [[DRDetailtitleCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.titlelb.text=_datasource[indexPath.row];
        cell.textlb.text=isnull(_dict[_keydatas[indexPath.row]]);
        
        return cell;
    }
   
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
