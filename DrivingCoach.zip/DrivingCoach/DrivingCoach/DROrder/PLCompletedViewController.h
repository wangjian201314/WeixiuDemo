//
//  PLCompletedViewController.h
//  PlaceOrder
//
//  Created by Mac on 2019/6/29.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PLCompletedViewController : MTBaseViewController
@property (nonatomic,strong)NSDictionary *dict;
@end

NS_ASSUME_NONNULL_END
