//
//  DROrderViewController.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DROrderViewController.h"
#import "HBTitleView.h"
#import "DROrderCell.h"
#import "DRDetailViewController.h"
@interface DROrderViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSMutableArray *_datasource;
    NSInteger _types;
}
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (strong, nonatomic) HBTitleView *hbTitleView;//top
@end

@implementation DROrderViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
    [_datasource removeAllObjects];
    [self.tableview reloadData];
    [self.tableview.mj_header beginRefreshing];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setNaviTitle:@"学员考试" leftButtonShow:NO rightButtom:nil];
     _datasource=[NSMutableArray array];
    [self.view addSubview:self.hbTitleView];
    [self setUITableview];
    self.hbTitleView.titleBtnBlock = ^(NSInteger index, NSString *title) {
        
        if(index==0){
            
            _types=0;
            [_datasource removeAllObjects];
            [_tableview reloadData];
            [_tableview.mj_header beginRefreshing];;
        }else{
            _types=1;
            [_datasource removeAllObjects];
            [_tableview reloadData];
            [_tableview.mj_header beginRefreshing];;
        }
    };
}

- (void)getdata{
    
    if(_types==0){
    [_datasource addObjectsFromArray :@[@{@"id":@"科目一",
                                       @"date":@"2019-06-10 09:06:30",
                                       @"status":@"通过",
                                       @"推送标识":@(1),
                                       @"color":@"#66CDAA",
                                        @"test":@"100分",
                                        @"name":@"王先生",
                                        @"tel":@"186****6544",
                                          @"adress":@"W区1栋102",
                                          @"question":@"感觉自己太粗心了，填错答案了",
                                          @"num":@"第一次考试",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"11"]),
                                       },
                                        @{@"id":@"科目三",
                                          @"date":@"2019-06-12 12:30:00",
                                          @"status":@"通过",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"90分",
                                          @"name":@"李先生",
                                          @"tel":@"189****0288",
                                          @"adress":@"W区2栋202",
                                          @"question":@"终于过了，哈哈哈哈哈哈哈哈哈哈或或或或或或或或或或或或",
                                          @"num":@"第二次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"22"]),
                                          },
                                        @{@"id":@"科目三",
                                          @"date":@"2019-07-02 17:30:00",
                                          @"status":@"通过",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"90分",
                                          @"name":@"刘先生",
                                          @"tel":@"155****8735",
                                          @"adress":@"c区2栋103",
                                          @"question":@"吸取上次的教训，这次稳了",
                                          @"num":@"第三次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"33"]),
                                          },
                                        @{@"id":@"科目四",
                                          @"date":@"2019-07-01 16:00:00",
                                          @"status":@"通过",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"96分",
                                          @"name":@"行先生",
                                          @"tel":@"187****6665",
                                          @"adress":@"c区2栋103",
                                          @"question":@"挺简单的啊，拿驾照轻松",
                                          @"num":@"第一次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"44"]),
                                          },
                                        @{@"id":@"科目二",
                                          @"date":@"2019-06-30 17:30:00",
                                          @"status":@"通过",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"90分",
                                          @"name":@"周小姐",
                                          @"tel":@"187****8095",
                                          @"adress":@"c区2栋103",
                                          @"question":@"挺好玩的，感觉人生已经到达了巅峰",
                                          @"num":@"第二次补考",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"55"]),
                                          },
                                        @{@"id":@"科目一",
                                          @"date":@"2019-06-27 09:30:00",
                                          @"status":@"通过",
                                          @"推送标识":@(1),
                                          @"color":@"#66CDAA",
                                          @"test":@"92分",
                                          @"name":@"陈小姐",
                                          @"tel":@"189****8225",
                                          @"adress":@"花园区2栋103",
                                          @"question":@"感觉很简单啊，比上学还简单",
                                          @"num":@"第一次考试",
                                          @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"66"]),
                                          },
                                     ]];
    }else{
        
        [_datasource addObjectsFromArray :@[@{@"id":@"科目二",
                                              @"date":@"2019-06-16 12:20:30",
                                              @"status":@"失败",
                                              @"推送标识":@(1),
                                              @"color":@"#66CDAA",
                                              @"test":@"80分",
                                              @"name":@"五先生",
                                              @"tel":@"187****6034",
                                              @"adress":@"c区2栋103",
                                              @"question":@"又没了兄弟，考驾照简直要命啊",
                                              @"num":@"第三次补考",
                                              @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"77"]),
                                              },
                                            @{@"id":@"科目二",
                                              @"date":@"2019-06-17 12:30:00",
                                              @"status":@"失败",
                                              @"推送标识":@(1),
                                              @"color":@"#66CDAA",
                                              @"test":@"70分",
                                              @"name":@"李先生",
                                              @"tel":@"189****0288",
                                              @"adress":@"d区1栋403",
                                              @"question":@"有点难啊，不知道别人怎么考的额",
                                              @"num":@"第二次补考",
                                              @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"88"]),
                                              },
                                            @{@"id":@"科目三",
                                              @"date":@"2019-07-02 17:30:00",
                                              @"status":@"失败",
                                              @"推送标识":@(1),
                                              @"color":@"#66CDAA",
                                              @"test":@"80分",
                                              @"name":@"吴小姐",
                                              @"tel":@"185****8035",
                                              @"adress":@"r区3栋203",
                                              @"question":@"没事没事，下次再努力学习吧",
                                              @"num":@"第三次补考",
                                              @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"99"]),
                                              },
                                            @{@"id":@"科目四",
                                              @"date":@"2019-07-01 16:00:00",
                                              @"status":@"失败",
                                              @"推送标识":@(1),
                                              @"color":@"#66CDAA",
                                              @"test":@"88分",
                                              @"name":@"赵先生",
                                              @"tel":@"189****6005",
                                              @"adress":@"b区4栋202",
                                              @"question":@"就差那么一点点啊，算了明天再来一趟",
                                              @"num":@"第三次补考",
                                              @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"33"]),
                                              },
                                            @{@"id":@"科目二",
                                              @"date":@"2019-06-30 17:30:00",
                                              @"status":@"失败",
                                              @"推送标识":@(1),
                                              @"color":@"#66CDAA",
                                              @"test":@"80分",
                                              @"name":@"周小姐",
                                              @"tel":@"188****8005",
                                              @"adress":@"g区3栋203",
                                              @"question":@"吸取上次的教训，这次稳了",
                                              @"num":@"第三次补考",
                                              @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"44"]),
                                              },
                                            @{@"id":@"科目一",
                                              @"date":@"2019-06-27 09:30:00",
                                              @"status":@"失败",
                                              @"推送标识":@(1),
                                              @"color":@"#66CDAA",
                                              @"test":@"86分",
                                              @"name":@"刘小姐",
                                              @"tel":@"181****8225",
                                              
                                              @"adress":@"h区3栋503",
                                              @"question":@"年纪大了，有点记忆力衰退",
                                              @"num":@"第三次补考",
                                              @"img":UIImagePNGRepresentation([ UIImage imageNamed:@"100"]),
                                              },
                                            ]];
    }
    [self.tableview reloadData];
}
- (HBTitleView *)hbTitleView
{
    if (_hbTitleView == nil)
    {
        
        _hbTitleView = [[HBTitleView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 45) andTitles:@[@"已通过",@"未通过"]];
        
        [_hbTitleView updataIndexLabelUIWithNum:0];
    }
    return _hbTitleView;
}
- (void)setUITableview{
    
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    [self.tableview registerNib:[UINib nibWithNibName:@"DROrderCell" bundle:nil] forCellReuseIdentifier:@"DROrderCell"];
    self.tableview.tableFooterView=[[UIView alloc]initWithFrame:CGRectZero];
    self.tableview.mj_header = [MJRefreshGifHeader  headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    [_tableview.mj_header beginRefreshing];
}

- (void)headerRefresh{
    
    
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableview.mj_header endRefreshing];
        
        id namestr=[[NSUserDefaults standardUserDefaults]objectForKey:@"username"];
        if([namestr isEqualToString:@"15976070261"]){
            [self getdata];
        }else{
           
            [SVProgressHUD showErrorWithStatus:@"暂无学员考试数据!"];
            
            
        }
    });
}




#pragma mark - UITableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _datasource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 184;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"DROrderCell";
    
    DROrderCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil) {
        cell = [[DROrderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    if(_datasource.count>0){
        NSDictionary *dict=_datasource[indexPath.row];
        cell.namelb.text=dict[@"name"];
        cell.typelb.text=dict[@"id"];
        cell.gradelb.text=dict[@"test"];
        cell.tellb.text=dict[@"tel"];
        cell.datelb.text=dict[@"date"];
         [cell.statusbtn setTitle:dict[@"status"] forState:UIControlStateNormal];
        if(_types==0){
            [cell.statusbtn setBackgroundColor:[UIColor colorWithHexString:@"#00CD00"]];
           
        }else{
            [cell.statusbtn setBackgroundColor:[UIColor redColor]];
        }
        
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DRDetailViewController *vc=[[DRDetailViewController alloc]init];
    NSDictionary *dict=_datasource[indexPath.row];
    vc.dict=dict;
    [self pushViewController:vc];
    
}



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

