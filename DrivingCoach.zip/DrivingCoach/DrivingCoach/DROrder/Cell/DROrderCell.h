//
//  DROrderCell.h
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DROrderCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *namelb;
@property (weak, nonatomic) IBOutlet UILabel *typelb;
@property (weak, nonatomic) IBOutlet UILabel *tellb;
@property (weak, nonatomic) IBOutlet UIButton *statusbtn;
@property (weak, nonatomic) IBOutlet UILabel *gradelb;
@property (weak, nonatomic) IBOutlet UILabel *datelb;

@end

NS_ASSUME_NONNULL_END
