//
//  DROrderCell.m
//  DrivingCoach
//
//  Created by Mac on 2019/7/1.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "DROrderCell.h"

@implementation DROrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.statusbtn.layer.masksToBounds=YES;
    self.statusbtn.layer.cornerRadius=10;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
