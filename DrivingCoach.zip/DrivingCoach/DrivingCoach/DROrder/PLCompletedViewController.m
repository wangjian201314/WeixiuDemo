//
//  PLCompletedViewController.m
//  PlaceOrder
//
//  Created by Mac on 2019/6/29.
//  Copyright © 2019年 Mac. All rights reserved.
//

#import "PLCompletedViewController.h"
#import "UITextView+Placeholder.h"
@interface PLCompletedViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *textlb;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (nonatomic,strong)UIButton *bottombtn;
@property (weak, nonatomic) IBOutlet UIButton *uploadbtn;
@property (weak, nonatomic) IBOutlet UIButton *addimgbtn;
@property (nonatomic,strong)UIButton *bottombtn2;
@end

@implementation PLCompletedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setNaviTitle:@"立即评价" leftButtonShow:YES rightButtom:nil];
   
    [self.textView setPlaceHolder:@"请填写评价(10字以上)!"];
    self.textView.layer.cornerRadius = 5.0;
    self.textView.layer.borderColor = [UIColor orangeColor].CGColor;
    self.textView.layer.borderWidth = 1;
    self.textView.layer.masksToBounds = YES;
    self.uploadbtn.layer.masksToBounds=YES;
    self.uploadbtn.layer.cornerRadius=10;
   
}

- (void)bottomclick2{
   
}
- (IBAction)addimg:(UIButton *)sender {
     [self recognize];
}
- (IBAction)uoloadbtn:(UIButton *)sender {
    
    if([self.textView.text isEqualToString:@""] || self.textView.text.length==0){
        [SVProgressHUD showErrorWithStatus:@"评价不能为空哦"];
        
        return;
    }else{
        
         dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
            [SVProgressHUD showSuccessWithStatus:@"评价成功!"];
            [self.navigationController popToRootViewControllerAnimated:YES];
        });
    }
}

- (void)recognize{
    
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册选择", nil];
    sheet.delegate=self;
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerControllerSourceType sourcetape=UIImagePickerControllerSourceTypeCamera;
    //    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
    
    switch (buttonIndex) {
        case 0:
            sourcetape=UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            sourcetape=UIImagePickerControllerSourceTypePhotoLibrary;
            break;
        case 2:
            
            return;
            break;
        default:
            break;
    }
    
    //    }
    UIImagePickerController  *imagepicker=[[UIImagePickerController alloc]init];
    imagepicker.delegate=self;
    imagepicker.allowsEditing=YES;
    imagepicker.sourceType=sourcetape;
    [self presentViewController:imagepicker animated:NO completion:nil];
    
}
- ( void )imagePickerController:( UIImagePickerController *)picker didFinishPickingMediaWithInfo:( NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:nil];
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    [self.addimgbtn setImage:image forState:UIControlStateNormal];
}

- (void)saveImage:(UIImage *)img withname:(NSString *)name{
    
    NSData *imgdata=UIImageJPEGRepresentation(img, 0.5);
    NSString *path=[[ NSSearchPathForDirectoriesInDomains ( NSDocumentDirectory , NSUserDomainMask , YES ) firstObject ]stringByAppendingPathComponent:name];
    BOOL ishave= [imgdata writeToFile:path atomically:NO];
    if(ishave){
        
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
